	jQuery('document').ready(function(){
				jQuery('.owl-carousel').owlCarousel({
					loop:true,
					margin:10,
					nav:true,
                    autoplay: 100,
                    responsiveClass:true,
					responsive:{
						0:{
							items:1
						},
						600:{
							items:3
						},
						1000:{
							items:5
						}
					}
				});


			});




			

			jQuery(document).ready(function () {
				jQuery(".accordion_head").click(function () {
					if ($('.accordion_body').is(':visible')) {
						$(".accordion_body").slideUp(300);
						$(".plusminus").text('+');
					}
					if ($(this).next(".accordion_body").is(':visible')) {
						$(this).next(".accordion_body").slideUp(300);
						$(this).children(".plusminus").text('+');
					} else {
						$(this).next(".accordion_body").slideDown(300);
						$(this).children(".plusminus").text('-');
					}
				});
			});
			
			jQuery(document).ready(function(){
    
				jQuery('.testing').keyup(function(){
					values =    jQuery(this).val();
					if(values.length >= 3){
							jQuery.ajax({
								type : "post",
								url : 'http://localhost/blog/wp-admin/admin-ajax.php',
								data : {
									action: "searchposts",
									titles : values},
								success: function(response) {
									jQuery('#showPosts').html (response);
								}
							});  
					}
					});
				
			
			
			});


					  
				
				   
				
			
			
			$(document).ready(function() {

				//MOBILE ONE AND MOBILE THREE
				var menu = "close";
				$(".mobile-one .menu-toggle, .mobile-three .menu-toggle").click(function() {
					
					if (menu === "close") {
						  $(this).parent().next(".mobile-nav").css("transform", "translate(0, 0)");
						  menu = "open";
					} else {
						  $(this).parent().next(".mobile-nav").css("transform", "translate(-100%, 0)");
						  menu = "close";
					}
				});
			
				
				});

			

			

				



				// jQuery(document).ready(function(){
				// 	jQuery(".flex-control-thumbs li").children().mouseenter(function(){
				// 	let hrefval = jQuery(this).attr('src');
				// 	jQuery('.woocommerce-product-gallery__image.flex-active-slide a').attr("src",$(this).attr("src",hrefval))
				// 		});
				// 	});
					


				// jQuery(".flex-control-thumbs li img").mouseover(function(){
				// 	var thumbnailURL = jQuery(this).attr('src');
				// 	var count = jQuery('.woocommerce-product-gallery__wrapper .woocommerce-product-gallery__image').length;
				// 	var thumb = jQuery(".woocommerce-product-gallery__wrapper").find(".woocommerce-product-gallery__image").attr('data-thumb')
				// 	var thumbnailData = jQuery(".woocommerce-product-gallery__image").attr('data-thumb');
					
				// 	if(thumbnailURL==thumb) {
				// 		jQuery(".woocommerce-product-gallery__image").addClass(".flex-active-slide");
				// 		jQuery(this).addClass("flex-active");
				// 	}
				// });



				